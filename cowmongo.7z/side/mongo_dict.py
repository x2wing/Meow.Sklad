from cowmongo import DBMongoMain
from cowmongo.settings import CONFIG_MONGO
from cowmongo.elementary import _find_one

client = DBMongoMain(CONFIG_MONGO)
collection = client['cow']['test']


def _insert_attr(collection, where, key, value):
    update = {'$set': {f'attrs.{key}': value}}
    collection.update_one(where, update)


def main(key, value):
    # where = {'_id': ObjectId('5d37e1c40f7f3c3f98bb789b')}
    where = {'_id': 1}

    # _insert_attr(collection, where, update)


if __name__ == '__main__':
    # print(len(attrs))
    # pprint(attrs)
    # _drop(collection)
    where = {'path': 'Object settings/wellImageSettings'}
    print(_find_one(collection, where))
    # for path, attrs in attrs.items():
    #     where = {'path': path}
    #     _insert(collection, where)
    #     for key, value in attrs.items():
    #         update = {'$set': {f'attrs.{key}': value}}
    #         insert_attr(collection, where, update)
