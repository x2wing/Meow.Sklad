import tempfile

# название дефолтной БД
from pymongo import MongoClient

DATABASE = 'cow2'
# название дефолтной коллекции
DATA_COL = 'main'
# размер чанка GridFS
CHUNK_SIZE = 15 * 1024 * 1024
# CHUNK_SIZE = 1 * 10 * 1024
# temp_path = 'obj' - работает медленно т.к. надо создавать порядка 200 000 файлов на проект
# temp_path = io.BytesIO() # работае прекрасно только много памяти
# временный файл
TEMPFILE = tempfile.SpooledTemporaryFile(max_size=CHUNK_SIZE * 4)
# конфиг подключения к MongoDB
CONFIG_MONGO = dict(host='10.205.103.3', port=27017, username=None, password=None)
# счетчик
COUNTER = 'counter'
# название поля содержащего путь вида /Геомодель/pools/Grid1
PATH = 'path'
# с какого размера датасет считается "Большим"
BIG_DATASET_MIN_SIZE = 2 * 1024 ** 3

ZARR_COLLECTION = 'zarr'

CLIENT = None

def get_db(config_params):
    global CLIENT
    """
    Функция получения инстанса подключения к бд
    :param config_params: параметры подключения к MongoDB
    :return: инстанс MongoClient
    """

    if CLIENT:
        return CLIENT
    # если в config_params есть имя пользователя то нужен authMechanism='SCRAM-SHA-256'
    if config_params['username']:
        CLIENT = MongoClient(**config_params,
                             authMechanism='SCRAM-SHA-256', compressors="snappy", maxPoolSize=50)
    # если доступ не авторизованный просто передаем параметры
    else:
        CLIENT = MongoClient(**config_params, compressors="snappy", maxPoolSize=50)
    return CLIENT
