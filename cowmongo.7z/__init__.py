__version__ = '0.1.0'


from cowmongo.cow import *
from cowmongo.db_store import Simple_Store
from cowmongo.settings import CONFIG_MONGO