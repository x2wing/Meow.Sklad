# def _update( collection, **kargs):
#     path, update = kargs.pop('path'), kargs
#     return collection.update_one({'path': path}, {'$set': update}, upsert=True)
from pymongo import ReturnDocument



def _update(collection, filter, update, upsert=True):
    return collection.update_one(filter, update, upsert=upsert)


# def _base_update( collection, **kargs):
#     return collection.update_one({'path': path}, {'$set': update}, upsert=True)

def _insert(collection, query):
    return collection.insert_one(query)


def _insert_many(collection, documents):
    """
    :param collection: mongodb коллекция
    :param documents: список или итератор по дукументам
    :return:  pymongo.results.InsertManyResult
    """
    return collection.insert_many(documents, ordered=False)


def _update_many():
    pass


def _copy_collection(collection, new_name):
    collection.aggregate([{'$out': new_name}])


def _create_index(collection, key):
    collection.create_index(key)


def _find_one(collection, where, select=None):
    return collection.find_one(where, select, no_cursor_timeout=True)


def _find(collection, where, select):
    return collection.find(where, select, no_cursor_timeout=True)


def _delete_one(collection, where):
    return collection.delete_one(where)


def _find_one_and_delete(collection, where, select):
    return collection.find_one_and_delete(where, select)


def _find_one_and_update(collection, where, update, select=None):
    return collection.find_one_and_update(where, update, select, return_document=ReturnDocument.AFTER)


def _find_one_and_upsert(collection, where, update, select=None):
    return collection.find_one_and_update(where, update, select, upsert=True, return_document=ReturnDocument.AFTER)


def _drop(collection):
    return collection.drop()


def _count_documents(collection, where):
    return collection.count_documents(where)
