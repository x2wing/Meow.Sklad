import hashlib
from time import monotonic

import numpy as np
import h5py
import zarr
from cowmongo.settings import CHUNK_SIZE, TEMPFILE, CONFIG_MONGO


def h5_dataset_copy(dst_file_obj, src_h5_obj, filename):
    with h5py.File(dst_file_obj, mode='w') as dst:
        dst.copy(src_h5_obj, filename)

def get_md5_bytes(path):
    # если байт-строка - просто пропускаем через метод md5
    return hashlib.md5(path.read()).hexdigest()


def NumpySerializator(TEMPFILE, array, **kargs):
    np.save(TEMPFILE, array, allow_pickle=True)


def HDF5Serializator(TEMPFILE, array, **kargs):
    with h5py.File(TEMPFILE, mode='w') as dst:
        dst.create_dataset('D', data=array)


def ZarrSerializator(TEMPFILE, array, **kargs):
    database = kargs['database']
    collection = kargs['collection']
    config_params = kargs['config_params']
    store = zarr.MongoDBStore(database=database, collection=collection, **config_params)
    root = zarr.group(store)
    x = max(array.shape)  # самая большая ось
    if isinstance(array, np.ndarray):
        all_size = array.nbytes
    elif isinstance(array, h5py.Dataset):
        all_size = array.size
    else:
        raise TypeError('неизвестный тип')
    num_chunks = all_size / CHUNK_SIZE  # количество чанков
    ch_size = int(x / num_chunks)  # первая размерность чанка

    if ch_size != 0:
        chunks = (ch_size - 2,)
    else:
        chunks = False
    print("размерность чанка", chunks)

    a = root.array(name=kargs['name'], data=array, dtype=array.dtype, chunks=chunks, cache_metadata=True)
    a


if __name__ == '__main__':
    start = monotonic()
    # from test.test_data import arr
    path = r"D:\GEOSIM PROJECTS\big_ZCORN"
    dset_name = 'Геомодель/pools/Grid-1/ZCORN'
    with h5py.File(path, mode='r') as src:
        arr = src[dset_name]
        # arr = np.arange(3*7*5, dtype=np.float).reshape(3,7,5)

        kargs = dict(config_params=CONFIG_MONGO,
                     database='cow',
                     collection='zarr',
                     name=dset_name)

        ZarrSerializator(TEMPFILE, arr, **kargs)
    print(monotonic() - start)
