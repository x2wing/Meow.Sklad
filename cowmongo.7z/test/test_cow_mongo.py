import unittest
import uuid
from time import monotonic

import h5py
import numpy
import numpy as np
# import h5py
import random
import hashlib
from bson import ObjectId

from cowmongo.cow import Store, CONFIG_MONGO, Tree
from cowmongo.test.test_data import project, arr
from cowmongo.elementary import _insert, _find, _find_one


def get_md5(path):
    """
    Универсальная функция получения хэша
    :param path: bytes, str, tempfile.SpooledTemporaryFile
        вход функции бинарная строка или путь
    return: hex хэш
    """

    return hashlib.md5(path.encode('utf-8')).hexdigest()




class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.t = Tree(CONFIG_MONGO)

    def test_get(self):
        pass

    def test_set(self):
        path = random.choice(list(project))
        uid = project[path]
        data = arr
        self.t.set(path, uid, data)
        # self.t.set(random.choice(list(project)), arr)

    def test_delete(self):
        del self.t['Геомодель/wells/179BH2/rigis26298']


class StoreModuleTest(unittest.TestCase):
    def setUp(self):
        self.store = Store(CONFIG_MONGO)
        self._id = "5d3690289de53342d05f5224"

    def test_science_performance_insert(self):
        colection = self.store.db['science_performance']
        for i in range(300_000):
            data = {
                'hash_': get_md5(str(i)),
                'data': i,
            }
            _insert(colection, data)

    def test_science_performance_find_one(self):
        colection = self.store.db['science_performance']
        for i in range(5000):
            hash = get_md5(str(random.randint(0, 300_000)))
            where = {'hash_': hash}
            select = {'_id': 0, 'hash_': 1}
            print(i, _find_one(colection, where, select))

    def test_increment(self):
        _id = ObjectId(self._id)
        before = self.store.get_counter(_id)
        self.store.inc(_id)
        after = self.store.get_counter(_id)
        self.assertEqual(before + 1, after)

    def test_decrement(self):
        _id = ObjectId(self._id)
        before = self.store.get_counter(_id)
        self.store.dec(_id)
        after = self.store.get_counter(_id)
        self.assertEqual(before - 1, after)

    def test_del_by_0_count(self):
        _id = ObjectId(self._id)
        while True:
            try:
                self.store.dec(_id)
            except TypeError as error:
                print(error)
                break


class AttrsModuleTest(unittest.TestCase):
    def setUp(self):
        self.t = Tree(CONFIG_MONGO)
        self._id = "5d3690289de53342d05f5224"
        self.path = 'Геомодель/wells/179BH2/rigis16694'
        self.key = "@uuid10"
        self.value = '1234567890'
        self.fill_attrs()

    def fill_attrs(self):
        for i in range(10):
            key = f'@uuid{i}'
            value = str(uuid.uuid4())
            self.t.set_attr(self.path, key, value)

        self.t.set_attr(self.path, self.key, self.value)

    def test_set_attr(self):
        key = "@uuid11"
        value = '0987654321'
        self.t.set_attr(self.path, key, value)
        self.assertEqual(self.t.get_attr(self.path, key), value)

    def test_get_attr(self):
        self.assertEqual(self.t.get_attr(self.path, self.key), self.value)


class Performance(unittest.TestCase):
    def setUp(self):
        self.t = Tree(CONFIG_MONGO)

    def test_fill(self):
        start = monotonic()
        for _ in range(1300):
            i = random.randint(0, 30000 - 1)
            id___ = 'Геомодель/wells/179BH2/rigis' + str(i)
            x, y = (570, 570)
            arr = np.arange(x * y, dtype=np.float64).reshape((x, y))
            self.t[id___] = arr
            # self.t[id___]
        print('time', monotonic() - start)

    def test_purefill(self):
        start = monotonic()
        for _ in range(100000):
            i = random.randint(0, 100000 - 1)
            id___ = 'Геомодель/wells/179BH2/rigis' + str(i)
            self.t.serializator.set(id___, np.arange(10000, dtype=np.float64).reshape((100, 100)))
            # self.t[id___]
        print('time', monotonic() - start)

    def test_random_get_data(self):
        L = [item['path'] for item in self.t]
        start = monotonic()
        for path in L:
            self.t[path]
        print('time', monotonic() - start)

    def test_prefix_search(self):
        for i in self.t.prefix_search('Геомодель/wells/179BH2/rigis10'):
            print(i.shape)
            print(i)


class H5ProjectConverter(unittest.TestCase):
    def setUp(self):
        self.t = Tree(CONFIG_MONGO)
        self.file = r"D:\GEOSIM PROJECTS\entel_gm (2).h5geo"

    def walker(self, name, obj):
        # if name.find('ZCORN') >= 0:
        #     return None

        # if name.find('Grid') < 0:
        #     return None

        if isinstance(obj, h5py.Dataset):
            self.t.set_data(name, obj)
        elif isinstance(obj, h5py.Group):
            self.t.insert(path=name, id_=None)

        for key, value in obj.attrs.items():
            if isinstance(key, str):
                key = key.replace('$', '#')

            if isinstance(value, numpy.bool_):
                value = bool(value)
            elif isinstance(value, (numpy.int32, numpy.int64)):
                value = int(value)
            elif isinstance(value, (numpy.float32, numpy.float64)):
                value = float(value)
            elif isinstance(value, numpy.ndarray):
                value = value.tolist()

            print(name, key, value, type(value))
            self.t.set_attr(name, key, value)

    def test_convert(self):
        with h5py.File(self.file, mode='r') as src:
            src.visititems(self.walker)

    def test_reader(self):
        pass

    def test_prefix_search_tree(self):
        cur = self.t.prefix_search_tree('')
        # print("число документов", cur.count())
        dsets = [item['path'] for n, item in enumerate(cur) if item['id_']]
        print(len(dsets))
        for i in range(100):
            dset = random.choice(dsets)
            if dset.find('tasks') < 0 and \
                    dset.find('well_info') < 0 and \
                    dset.find('markers') < 0 and \
                    dset.find('Windows') < 0 and \
                    dset.find('Стратиграфическая модель') < 0:
                print(dset)
                self.t[dset]


class Administration(unittest.TestCase):
    def setUp(self):
        self.t = Tree(CONFIG_MONGO)

    def test_copycollection(self):
        self.t.fork('Версия2')


if __name__ == '__main__':
    unittest.main()
