from .cow import Store, Serializator, TEMPFILE
from .serializators import h5_dataset_copy, get_md5_bytes


class Simple_Store(Serializator):

    def serialize(self, h5_obj, name):
        h5_dataset_copy(TEMPFILE, h5_obj, 'dataset')
        TEMPFILE.seek(0)
        print('MD5=', get_md5_bytes(TEMPFILE))

    def deserialize(self):
        pass

    def set(self, name, h5_obj):
        TEMPFILE.truncate(0)
        TEMPFILE.seek(0)
        self.serialize(h5_obj, name)
        TEMPFILE.seek(0)
        return self.upload(name, metadata={name: 'name'})  # , metadata={'$inc': {COUNTER: 1}})
