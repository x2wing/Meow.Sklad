from cowmongo.cow import Store


class DB:
    def get(self, key):
        return Store.download_by_id(key)



    def set(self, key, data):

        Store.upload()
