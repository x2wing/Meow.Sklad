############################################
# 100000 объектов 316 сек
# 24,5 ГБ 783.40 сериализатор hdf5
# 24,5 ГБ 746.45
#
#


import logging

from bson import ObjectId
from gridfs import GridFSBucket
from cowmongo.elementary import _update, _copy_collection, _insert, _find_one, _create_index, _find, \
    _find_one_and_delete, _find_one_and_update, _find_one_and_upsert, _count_documents
import numpy as np

from cowmongo.serializators import ZarrSerializator
from cowmongo.settings import *


class DBMongoMain:
    """ класс получения инстанса БД и тестирование подключения"""

    def __init__(self, config_params):
        self.client = get_db(config_params)

    def test_connection(self):
        return self.client.server_info()
        # return self.main_collection.command('ping')

    def __getitem__(self, key):
        return self.client[key]


class DBMongoBase(DBMongoMain):
    """лайтовый класс для получения списков (например списка всех проектов)"""

    def __init__(self, config_params, database):
        super().__init__(config_params)
        self.db = self.client[database]


class Store(DBMongoBase):
    """Класс работы с MongoDB Gridfs"""

    def __init__(self, config_params, database='cow'):
        """Получаем базу, GridFSBucket, коллекцию
        :param config_params: dict
            словарь конфигурационных парметров
            dict(host='10.205.33.221', port=27017, username=None, password=None)
        :param database: string
            название базы данных MongoDB
        """
        super().__init__(config_params, database)

        # получаем GridFSBucket
        self.fs = GridFSBucket(self.db)
        # получаем коллекцию fs.files - стандартная коллекция GridFSBucket
        self.fs_files = self.db.fs.files
        # проверяем права доступа и существование подключения к БД
        self.check_access()

        print(self.__class__, self.db)

    def check_access(self):
        """Проверка установления подключения к бд"""
        try:
            self.fs_files.find_one({})
        except Exception as error:
            print("У вас нет прав доступа к этой базе данных. "
                  "Измените базу данных или обратитесь к администратору", error)

    def download(self, id_: str):
        """
        Загрузка данных из БД
        :param id_:  ObjectId уникальный идентификатор блоба
        :return: возвращает
        """
        assert id_, "_id None."
        # загрузка блоба во временный файл
        return self.fs.download_to_stream(ObjectId(id_), TEMPFILE)

    def upload(self, filename, metadata={'count': 1}):
        """
        отгрузка сериализованных данных в БД
        :param filename: поле filename в GridFS
        :param metadata: дополнительные данные (счетчик ссылок)
        :return: ObjectId отгруженного блоба
        """
        return self.fs.upload_from_stream(filename, TEMPFILE, chunk_size_bytes=CHUNK_SIZE, metadata=metadata)

    def delete(self, id_):
        """ вызывается когда metadata.count = 0"""
        self.fs.delete(id_)

    def get_iter(self):
        pass

    def __inc(self, _id, change=1):
        """ Изменение счетчика ссылок"""
        filter = {'_id': _id}
        update = {'$inc': {'metadata.count': change}}
        # projection = {'_id': 0, 'metadata.count': 1}
        # устанавливаем новое значение счетчика +1 или -1 и получаем новое значение счетчика
        count = _find_one_and_update(self.fs_files, filter, update)['metadata']['count']
        # если число ссылок == 0
        if count == 0:
            # удаляем объект grid
            self.delete(_id)

    # def __inc_old(self, _id, change=1):
    #     if change == -1:
    #         count = self.get_counter(_id)
    #         if count <= 1:
    #             self.delete(_id)
    #             return
    # filter = {'_id': _id}
    # update = {'$inc': {'metadata.count': change}}
    # _update(self.fs_files, filter, update)

    def inc(self, _id, ):
        """+1. Увеличение счетчика на 1"""
        self.__inc(_id)

    def dec(self, _id):
        """-1. Уменьшение счетчика на 1"""
        self.__inc(_id, change=-1)

    def get_counter(self, _id):
        """ получить значение счетчика. Используется только в тестах"""
        where = {'_id': _id}
        select = {'_id': 0, 'metadata.count': 1}
        return _find_one(self.fs_files, where, select)['metadata']['count']


class Serializator(Store):
    """ Класс сериализации десериализации"""

    def __init__(self, config_mongo, database):
        super().__init__(config_mongo, database)
        # self.st = Store(config_mongo)


    def set_any(self):
        self.upload(name)



    def get(self, id_):
        TEMPFILE.truncate(0)
        TEMPFILE.seek(0)
        # загрузка данных  в TEMPFILE
        data = self.download(id_)
        # перемотка на начало
        TEMPFILE.seek(0)
        # десериализация и возвращения numpy массива
        return self.deserialize()




    def set(self, name, array):
        TEMPFILE.truncate(0)
        TEMPFILE.seek(0)
        self.serialize(array, name)
        TEMPFILE.seek(0)
        return self.upload(name)  # , metadata={'$inc': {COUNTER: 1}})

    #
    # def set(self, name, array):
    #
    #     if hasattr(array, 'nbytes'):
    #         size = array.nbytes
    #     elif hasattr(array, 'size'):
    #         size = array.size
    #     else:
    #         raise AttributeError("Не удалось получить размер массива")
    #
    #     if size > BIG_DATASET_MIN_SIZE:
    #         id_ = self._set_big(name, array)
    #     else:
    #         id_ = self._set_small(name, array)
    #
    #     return id_  # , metadata={'$inc': {COUNTER: 1}})

    # def _set_small(self, name, array):
    #     # транкейт и перемотка временного файла
    #     TEMPFILE.truncate(0)
    #     TEMPFILE.seek(0)
    #     # сериализация из numpy данных в TEMPFILE
    #     self.serialize(array)
    #     # перемотка на начало
    #     TEMPFILE.seek(0)
    #     # загрузка в БД и возвращение objectid
    #     return self.upload(name)
    #
    # def _set_big(self, name, array):
    #     kargs = dict(config_params=CONFIG_MONGO,
    #                  database=self.db.name,
    #                  collection=ZARR_COLLECTION,
    #                  name=name)
    #
    #     ZarrSerializator(name, array, **kargs)
    #     return ZARR_COLLECTION

    def serialize_h5(self, filepath):
        pass
        #with h5py.

    def serialize(self, array, name):
        """
        Сериализация numpy массива в TEMPFILE
        :param array: numpy
        :return: None
        """
        # serializator = NumpySerializator()
        # serializator = HDF5Serializator
        # serializator(TEMPFILE, array)
        np.save(TEMPFILE, array, allow_pickle=True)

    # def serialize2(self, array):
    #     def upload(self, obj_name, filepath, metadata):
    #         """метод загрузки данных в БД
    #         :param obj_name: string
    #             название объекта value поля filename
    #         :param filepath: file_object
    #             file_object с данными, отправляемыми в БД
    #         :param metadata: dict
    #             метаданные записываемые в БД
    #         return: None
    #         """
    #         # GridIn instance
    #         grid_in = self.fs.open_upload_stream(
    #             obj_name, chunk_size_bytes=CHUNK_SIZE,
    #             metadata=metadata)
    #         # with open(filepath, mode='rb') as dst:
    #         # Перемотаем буфер к началу
    #         filepath.seek(0)
    #         # запись данных
    #         grid_in.write(filepath)  # grid_in.write(file_like_obj)
    #         # закрываем instance при этом инициируется отправка  еще не отправленных данных
    #         grid_in.close()  # uploaded on close
    #         # обнулим буфер не удаляя объекта
    #         filepath.truncate(0)
    #         return grid_in._id

    def deserialize(self):
        """
        десериализация numpy массива
        :return: десериализованный numpy массив
        """
        return np.load(TEMPFILE)


class Tree(DBMongoBase):
    """класс дерева проекта"""
    # Кэш дерева пока не используется
    tree = {}

    def __init__(self, config_params, database='cow2', project='project'):
        super().__init__(config_params, database)
        # инстанс уровня базы данных
        self.db = self.client[database]
        # инстанс уровня коллекции
        self.project_col = self.db[project]
        # инстанс сериализатор + GridFS
        self.serializator = Serializator(config_params, database)
        # для ускорения поиска  по дереву нужет индекс по полю 'path'
        _create_index(self.project_col, PATH)
        # self.cache = Cache(CACHE_PATH)

    def get_id_by_path(self, path):
        """
        получение id обеъкта по пути
        :param path: путь вида'Геомодель/wells/179BH2/rigis'
        :return: ObjectId объекта
        """
        where = {PATH: path}
        select = {'_id': 0, 'id_': 1}
        response = _find_one(self.project_col, where, select)
        try:
            return response.get('id_', None)
        except Exception as error:
            print(error)



    def _get_data(self, path):
        """
        получить numpy массив по пути вида 'Геомодель/wells/179BH2/rigis'
        :param path: путь вида 'Геомодель/wells/179BH2/rigis'
        :return: numpy массив
        """
        # получаем id объекта
        id_ = self.get_id_by_path(path)
        # получаем сам десериализованный объект
        return self.serializator.get(id_)

    def set_data(self, path, data):
        """
        загрузка нового датасета
        :param path: путь вида'Геомодель/wells/179BH2/rigis'
        :param data: загружаемый numpy массив
        :return: None
        """

        # попытка отправить данные в БД
        try:
            id_ = self.serializator.set(path, data)
        except Exception as error:
            logging.debug(f'{__class__} {error} не удалось записать данные в БД ')
        # если данные успешно записаны нужно обработать ситуацию сущестовования или отсутствия узла
        else:
            self.meta_handler(path, id_)

    def meta_handler(self, path, new_id):
        where = {PATH: path}
        update = {'$set': {'id_': new_id}}
        _find_one_and_upsert(self.project_col, where, update)

    # def meta_handler1(self, path, new_id):
    #     # получаем старый id
    #     old_id = self.get_id_by_path(path)
    #     # если такой узел был
    #     if old_id:
    #         # значит узел будет ссылаться на другой объект поэтому число ссылок должно уменьшиться на 1
    #         self.serializator.dec(old_id)
    #         filter = {PATH: path}
    #         update = {'$set': {'id_': new_id}}
    #         # установим ссылку на новый объект
    #         _update(self.project_col, filter, update)
    #     # если такого узла не было
    #     else:
    #         # создаем новый
    #         self.insert(path=path, id_=new_id)

    # def set_attr(self, path, attrs):
    #
    #     """
    #     установить атрибуты
    #     :param path: путь вида'Геомодель/wells/179BH2/rigis'
    #     :param attrs: атрибуты
    #     :return:
    #     """
    #     filter = {PATH: path}
    #     update = {'$set': {'attrs': attrs}}
    #     _update(self.project_col, filter, update)

    def set_attr(self, path, key, value):
        where = {PATH: path}
        update = {'$set': {f'attrs.{key}': value}}
        _update(self.project_col, where, update)

    def get_attrs(self, path):
        """
        получение всех атрибутов данного объекта. Атрибуты хранятся в дереве
        :param path: путь вида'Геомодель/wells/179BH2/rigis'
        :return: dict словарь атрибутов
        """
        where = {PATH: path}
        select = {'_id': 0, 'attrs': 1}
        return _find_one(self.project_col, where, select)['attrs']

    def get_attr(self, path, attr):
        """
        Получение отдельного атрибута.
        :param path: путь вида'Геомодель/wells/179BH2/rigis'
        :param attr: название атрибута
        :return:
        """
        return self.get_attrs(path).get(attr, None)

    def insert(self, **kargs):
        """ добавление нового узла"""
        return _insert(self.project_col, kargs)



    def __delitem__(self, path):
        """ удалить узел"""
        response = _find_one_and_delete(self.project_col, {PATH: path}, {'id_': 1, '_id': 0})
        if response:
            self.serializator.dec(response['id_'])

    def __setitem__(self, path, data):
        """установить данные по имени"""
        self.set_data(path, data)

    def __getitem__(self, key):
        """получить данные по имени"""
        return self._get_data(key)

    def __iter__(self):
        """итератор по всем узлам"""
        return _find(self.project_col, {}, {'_id': 0})

    def __len__(self):
        _count_documents(self.project_col, {})

    def fork(self, dst_name):
        """
        Сделать копию проекта
        :param dst_name: название нового проекта
        :return:
        """
        _copy_collection(self.project_col, dst_name)
        _create_index(self.project_col, PATH)
        for id_ in _find(self.db[dst_name], {}, {'_id': 0, 'id_': 1}):
            self.serializator.inc(id_['id_'])

    def prefix_search_datasets(self, prefix):
        where = {PATH: {'$regex': f'^{prefix}'}}
        select = {'_id': 0, 'id_': 1}
        for dset_id in _find(self.project_col, where, select):
            yield self.serializator.get(dset_id['id_'])

    def prefix_search_tree(self, prefix):
        where = {PATH: {'$regex': f'^{prefix}'}}
        # where = {}
        select = {'_id': 0, PATH: 1, 'attrs': 1, 'id_': 1}
        # select = {'_id': 0, 'attrs': 0}
        return _find(self.project_col, where, select)


# class MyThread(Thread):
#     def __init__(self):
#         super().__init__(group=None)
#
#     def run(self):
#         print("Thread ", random.randint(0, 100))
#         for _ in range(10000):
#             i = random.randint(0, 1000000 - 1)
#             id___ = 'Геомодель/wells/179BH2/rigis' + str(i)
#             # t[id___] = np.arange(10000, dtype=np.float64).reshape((100, 100))
#             t[id___]
#             # if not i %100000:
#             #     print(i, monotonic() - start)
#         print(monotonic() - start)


if __name__ == '__main__':
    t = Tree(CONFIG_MONGO)
    # path = random.choice(list(project))
    # path = 'Геомодель/wells/179BH2/rigis'
    # uid = project[path]
    # data = arr
    # t.set_data(path, uid=uid, data=data)
    # t.set_attr('Геомодель/wells/179BH2/rigis', {'@typeid': 'wtraj', '@uid': 'a44df2fd-3d2e-43e8-9f82-cbf7365bb174',
    #                                               'Sign': -1.0, 'data_file': '', 'order': 0, 'time_created': 1548763292,
    #                                               'type_read': 1})
    # print(t.get_attrs('Геомодель/wells/179BH2/rigis'))
    # print(t.get_attrs('Геомодель/wells/179BH2/rigis', ))
    # id___ = 'Геомодель/wells/179BH2/rigis'
    # start = monotonic()
    # for i in range(4):
    #     thread1 = MyThread()
    #     thread1.start()
    # t = Tree(CONFIG_MONGO)
    cur = t.prefix_search_tree('')
    print("число документов", cur.count())
    for n, item in enumerate(cur):
        print(n, item)
